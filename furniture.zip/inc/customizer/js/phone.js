(function($) {
    'use strict';
    $(document).ready(function($) {


    $(".magazil-phone").intlTelInput();

    });
}(jQuery));