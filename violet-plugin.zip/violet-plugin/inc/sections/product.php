<?php
// products page layout
// function product_template($single_template) {
//      global $post;

//      if ($post->post_type == 'product') {
//           $single_template = dirname( __FILE__ ) . '/layouts/product.php';
//      }
//      return $single_template;
// }
// add_filter( 'single_template', 'product_template' );


// Registers the new post type 

function violet_product_posttype() {
	register_post_type( 'product',
		array(
			'labels' => array(
				'name' => __( 'Product', 'violet-plugin' ),
				'singular_name' => __( 'Product' , 'violet-plugin'),
				'add_new' => __( 'Add New Product', 'violet-plugin' ),
				'add_new_item' => __( 'Add New Product', 'violet-plugin' ),
				'edit_item' => __( 'Edit Product', 'violet-plugin' ),
				'new_item' => __( 'Add New Product', 'violet-plugin' ),
				'view_item' => __( 'View Product', 'violet-plugin' ),
				'search_items' => __( 'Search Product', 'violet-plugin' ),
				'not_found' => __( 'No Product found', 'violet-plugin' ),
				'not_found_in_trash' => __( 'No Product found in trash', 'violet-plugin' )
			),
			'menu_icon' 			=> 'dashicons-groups',
			'taxonomies' 			=> array('product_category'),
			'public' 				=> true,
			'supports' 				=> array( 'title', 'editor', 'thumbnail'),
			'capability_type' 		=> 'post',
			'rewrite'       		=> array( 'slug' => 'product', 'with_front' => true ), // Permalinks format
			'menu_position' 		=> 5,
			'exclude_from_search' 	=> true,
			'publicly_queryable' 	=> true,
			'show_ui'            	=> true,
			'show_in_menu'       	=> true,
			'query_var'          	=> true,
			'has_archive'        	=> true,
			'hierarchical'       	=> false,
		)
	);
	flush_rewrite_rules( true );
}

add_action( 'init', 'violet_product_posttype' );

//add taxonomies(product category)
function violet_taxonomies_product() {
	$labels = array(
		'name'              => _x( 'Product Categories', 'taxonomy general name' ),
		'singular_name'     => _x( 'Product Category', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Product Categories' ),
		'all_items'         => __( 'All Product Categories' ),
		'parent_item'       => __( 'Parent Product Category' ),
		'parent_item_colon' => __( 'Parent Product Category:' ),
		'edit_item'         => __( 'Edit Product Category' ), 
		'update_item'       => __( 'Update Product Category' ),
		'add_new_item'      => __( 'Add New Product Category' ),
		'new_item_name'     => __( 'New Product Category' ),
		'menu_name'         => __( 'Product Categories' ),
	);
	$args = array(
		'labels' => $labels,
		'query_var'         => true,
		'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_tagcloud'              => true,
		'rewrite'           => array( 'slug' => 'product_category' ),
	);
	register_taxonomy( 'product_category', 'product', $args );
}
add_action( 'init', 'violet_taxonomies_product', 0 );
